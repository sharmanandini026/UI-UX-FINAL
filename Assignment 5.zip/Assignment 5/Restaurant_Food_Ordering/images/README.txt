This folder contains the six food photo files used by the website:
pizza.jpg, burger.jpg, indian-food.jpg, noodles.jpg, dessert.jpg, drink.jpg
All image paths in index.html and style.css are relative to this folder.
